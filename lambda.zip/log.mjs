export function log(mensagem) {
    console.log('Adicionando log via função:', mensagem);
}
